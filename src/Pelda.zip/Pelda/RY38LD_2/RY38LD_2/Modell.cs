﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RY38LD_2
{
    public class Modell
    {
        private Int32[,] _tabla;
        private Int32[,] _fedett;
        private Int32 _fedettekszama;
        private Int32 _meret;
        private Int32 _bombakszama;
        private Int32 _lepesszam = 0;

        public Int32 Meret { get { return _meret; } set { _meret = value; }}
        public Int32 Lepesszam { get { return _lepesszam; } }
        public Int32 Tabla(Int32 i, Int32 j) { return _tabla[i, j]; }
        public Int32 Fedett(Int32 i, Int32 j) { return _fedett[i, j]; }

        public event EventHandler<EventArgs> TablaValtozas;
        private void Tablavaltozaskor()
        {
            if (TablaValtozas != null)
                TablaValtozas(this, new EventArgs());
        }

        public event EventHandler<JatekvegeArgumentumok> JatekVege;
        private void Jatekvegekor(Int32 gyozelem, Int32 nyertes)
        {
            if (JatekVege != null)
                JatekVege(this, new JatekvegeArgumentumok(gyozelem, nyertes));
        }

        public Modell()
        {
            _tabla = new Int32[16, 16];
            _fedett = new Int32[16, 16];
        }

        public void Ujjatek_Modell(Int32 meret)
        {
            _meret = meret;
            _lepesszam = 0;
            _fedettekszama = _meret * _meret;

            if (_meret == 6)
            {
                _bombakszama = _meret;
            }
            else if (_meret == 10)
            {
                _bombakszama = 2 * _meret;
            }
            else
            {
                _bombakszama = 3 * _meret;
            }
            for (Int32 i = 0; i < _meret; i++)
            {
                for (Int32 j = 0; j < _meret; j++)
                {
                    _tabla[i, j] = 0;
                    _fedett[i, j] = 1;
                }
            }

            Random random = new Random();
            Int32 a, b;
            for (Int32 i = 0; i < _bombakszama; i++)
            {
                a = random.Next() % _meret;
                b = random.Next() % _meret;
                while (_tabla[a, b] == -1)
                {
                    a = random.Next() % _meret;
                    b = random.Next() % _meret;
                }
                _tabla[a, b] = -1;
            }

            for (Int32 i = 0; i < _meret; i++)
            {
                for (Int32 j = 0; j < _meret; j++)
                {
                    if (_tabla[i, j] != -1)
                    {
                        if ((i - 1 >= 0) && (j - 1 >= 0) && (_tabla[i - 1, j - 1] == -1))
                        {
                            _tabla[i, j]++;
                        }
                        if ((i - 1 >= 0) && (_tabla[i - 1, j] == -1))
                        {
                            _tabla[i, j]++;
                        }
                        if ((i - 1 >= 0) && (j + 1 < _meret) && (_tabla[i - 1, j + 1] == -1))
                        {
                            _tabla[i, j]++;
                        }
                        if ((j - 1 >= 0) && (_tabla[i, j - 1] == -1))
                        {
                            _tabla[i, j]++;
                        }
                        if ((j + 1 < _meret) && (_tabla[i, j + 1] == -1))
                        {
                            _tabla[i, j]++;
                        }
                        if ((i + 1 < _meret) && (j - 1 >= 0) && (_tabla[i + 1, j - 1] == -1))
                        {
                            _tabla[i, j]++;
                        }
                        if ((i + 1 < _meret) && (_tabla[i + 1, j] == -1))
                        {
                            _tabla[i, j]++;
                        }
                        if ((i + 1 < _meret) && (j + 1 < _meret) && (_tabla[i + 1, j + 1] == -1))
                        {
                            _tabla[i, j]++;
                        }
                    }
                }
            }

            Tablavaltozaskor();
        }

        public void Lepes_Modell(Int32 sor, Int32 oszlop)
        {
            if (_fedett[sor, oszlop] == 1)
            {
                _fedett[sor, oszlop] = 0;
                _fedettekszama--;
                _lepesszam++;
                if (_tabla[sor, oszlop] == 0)
                {
                    Felfed(sor, oszlop);
                }
            }

            Tablavaltozaskor();
            Ellenoriz(sor, oszlop);
        }

        private void Ellenoriz(Int32 sor, Int32 oszlop)
        {
            if (_tabla[sor, oszlop] == -1)
            {
                Jatekvegekor(1, _lepesszam % 2 + 1);
            }
            if (_fedettekszama == _bombakszama)
            {
                Jatekvegekor(0, 0);
            }
        }

        private void Felfed(Int32 i, Int32 j)
        {
            if ((i - 1 >= 0) && (j - 1 >= 0) && (_fedett[i - 1, j - 1] == 1))
            {
                _fedett[i - 1, j - 1] = 0;
                _fedettekszama--;
                if ((_tabla[i - 1, j - 1] == 0))
                {
                    Felfed(i - 1, j - 1);
                }
            }
            if ((i - 1 >= 0) && (_fedett[i - 1, j] == 1))
            {
                _fedett[i - 1, j] = 0;
                _fedettekszama--;
                if ((_tabla[i - 1, j] == 0))
                {
                    Felfed(i - 1, j);
                }
            }
            if ((i - 1 >= 0) && (j + 1 < _meret) && (_fedett[i - 1, j + 1] == 1))
            {
                _fedett[i - 1, j + 1] = 0;
                _fedettekszama--;
                if (_tabla[i - 1, j + 1] == 0)
                {
                    Felfed(i - 1, j + 1);
                }
            }
            if ((j - 1 >= 0) && (_fedett[i, j - 1] == 1))
            {
                _fedett[i, j - 1] = 0;
                _fedettekszama--;
                if (_tabla[i, j - 1] == 0)
                {
                    Felfed(i, j - 1);
                }
            }
            if ((j + 1 < _meret) && (_fedett[i, j + 1] == 1))
            {
                _fedett[i, j + 1] = 0;
                _fedettekszama--;
                if (_tabla[i, j + 1] == 0)
                {
                    Felfed(i, j + 1);
                }
            }
            if ((i + 1 < _meret) && (j - 1 >= 0) && (_fedett[i + 1, j - 1] == 1))
            {
                _fedett[i + 1, j - 1] = 0;
                _fedettekszama--;
                if (_tabla[i + 1, j - 1] == 0)
                {
                    Felfed(i + 1, j - 1);
                }
            }
            if ((i + 1 < _meret) && (_fedett[i + 1, j] == 1))
            {
                _fedett[i + 1, j] = 0;
                _fedettekszama--;
                if (_tabla[i + 1, j] == 0)
                {
                    Felfed(i + 1, j);
                }
            }
            if ((i + 1 < _meret) && (j + 1 < _meret) && (_fedett[i + 1, j + 1] == 1))
            {
                _fedett[i + 1, j + 1] = 0;
                _fedettekszama--;
                if (_tabla[i + 1, j + 1] == 0)
                {
                    Felfed(i + 1, j + 1);
                }
            }
        }

        public void Betoltes_Modell(String filenev)
        {
            try
            {
                StreamReader olvaso = new StreamReader(filenev);

                String[] adatok = olvaso.ReadLine().Split(' ');
                _meret = Int32.Parse(adatok[0]);
                _bombakszama = Int32.Parse(adatok[1]);
                _fedettekszama = Int32.Parse(adatok[2]);
                _lepesszam = Int32.Parse(adatok[3]);

                for (Int32 i = 0; i < _meret; i++)
                {
                    adatok = olvaso.ReadLine().Split(' ');
                    for (Int32 j = 0; j < _meret; j++)
                    {
                        _tabla[i, j] = Int32.Parse(adatok[j]);
                    }
                }
                olvaso.ReadLine();
                for (Int32 i = 0; i < _meret; i++)
                {
                    adatok = olvaso.ReadLine().Split(' ');
                    for (Int32 j = 0; j < _meret; j++)
                    {
                        _fedett[i, j] = Int32.Parse(adatok[j]);
                    }
                }
                olvaso.Close();
            }
            catch
            {
                throw new FileKivetel();
            }
        }

        public void Mentes_Modell(String filenev)
        {
            try
            {
                StreamWriter iro = new StreamWriter(filenev);
                iro.Write(_meret + " ");
                iro.Write(_bombakszama + " ");
                iro.Write(_fedettekszama + " ");
                iro.Write(_lepesszam + " ");
                iro.WriteLine();
                for (Int32 i = 0; i < _meret; i++)
                {
                    for (Int32 j = 0; j < _meret; j++)
                    {
                        iro.Write(_tabla[i, j] + " ");
                    }
                    iro.WriteLine();
                }
                iro.WriteLine();
                for (Int32 i = 0; i < _meret; i++)
                {
                    for (Int32 j = 0; j < _meret; j++)
                    {
                        iro.Write(_fedett[i, j] + " ");
                    }
                    iro.WriteLine();
                }
                iro.Close();
            }
            catch
            {
                throw new FileKivetel();
            }
        }
    }
}
