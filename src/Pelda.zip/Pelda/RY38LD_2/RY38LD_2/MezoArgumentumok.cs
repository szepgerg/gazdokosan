﻿using System;

namespace RY38LD_2
{
    public class MezoArgumentumok : EventArgs
    {
        public Int32 Sor { get; set; }
        public Int32 Oszlop { get; set; }
    }
}
