﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RY38LD_2
{
    public class JatekvegeArgumentumok : EventArgs
    {
        private Int32 _gyozelem;
        private Int32 _nyertes;

        public Int32 Gyozelem { get { return _gyozelem; } }
        public Int32 Nyertes { get { return _nyertes; } }

        public JatekvegeArgumentumok(Int32 gyozelem, Int32 nyertes)
        {
            _gyozelem = gyozelem;
            _nyertes = nyertes;
        }

    }
}
