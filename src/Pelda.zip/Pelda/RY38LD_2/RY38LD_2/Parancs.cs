﻿using System;
using System.Windows.Input;

namespace RY38LD_2
{
    public class Parancs : ICommand
    {
        private readonly Action<Object> _vegrehajt;
        private readonly Func<Object, Boolean> _vegrehajthato;

        public Parancs(Action<Object> vegrehajt) : this(null, vegrehajt) { }

        public Parancs(Func<Object, Boolean> vegrehajthato, Action<Object> vegrehajt)
        {
            if (vegrehajt == null)
            {
                throw new ArgumentNullException("vegrehajt");
            }

            _vegrehajt = vegrehajt;
            _vegrehajthato = vegrehajthato;
        }

        public event EventHandler CanExecuteChanged;

        public Boolean CanExecute(Object parameter)
        {
            return _vegrehajthato == null ? true : _vegrehajthato(parameter);
        }

        public void Execute(Object parameter)
        {
            if (!CanExecute(parameter))
            {
                throw new InvalidOperationException("Parancs vegrehajtasa nem engedelyezett.");
            }
            _vegrehajt(parameter);
        }

        public void RaiseCanExecuteChanged()
        {
            if (CanExecuteChanged != null)
                CanExecuteChanged(this, EventArgs.Empty);
        }
    }
}
