﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Threading;
using System.Windows;

namespace RY38LD_2
{
    public class NezetModell : NezetModellAlap
    {
        private Modell _modell;

        public Parancs UjjatekParancs { get; private set; }
        public Parancs BetoltesParancs { get; private set; }
        public Parancs MentesParancs { get; private set; }

        public ObservableCollection<Mezo> Mezok { get; set; }

        public Int32 Meret
        {
            get { return _modell.Meret; }
            set
            {
                _modell.Meret = value;
                OnPropertyChanged("Meret");
            }
        }
        public String Jatekos
        {
            get 
            {
                 String lepes = (_modell.Lepesszam % 2 +1).ToString();
                 return "A(z) " + lepes + ". játékos következik.";
            }
            set
            {
                Jatekos = value;
                OnPropertyChanged("Jatekos");
            }
        }
        public Boolean Kicsi
        {
            get { return _modell.Meret == 6; }
            set
            {
                _modell.Meret = 6;
                OnPropertyChanged("Kicsi");
                OnPropertyChanged("Kozepes");
                OnPropertyChanged("Nagy");
            }
        }
        public Boolean Kozepes
        {
            get { return _modell.Meret == 10; }
            set
            {
                _modell.Meret = 10;
                OnPropertyChanged("Kicsi");
                OnPropertyChanged("Kozepes");
                OnPropertyChanged("Nagy");
            }
        }
        public Boolean Nagy
        {
            get { return _modell.Meret == 16; }
            set
            {
                _modell.Meret = 16;
                OnPropertyChanged("Kicsi");
                OnPropertyChanged("Kozepes");
                OnPropertyChanged("Nagy");
            }
        }

        public event EventHandler Ujjatek;
        private void Ujjatekkor()
        {
            if (Ujjatek != null)
                Ujjatek(this, EventArgs.Empty);
        }
        
        public event EventHandler Betoltes;
        private void Betolteskor()
        {
            if (Betoltes != null)
                Betoltes(this, EventArgs.Empty);
        }

        public event EventHandler Mentes;
        private void Menteskor()
        {
            if (Mentes != null)
                Mentes(this, EventArgs.Empty);
        }

        public event EventHandler<MezoArgumentumok> Lepes;
        private void Lepeskor(Object param)
        {
            Mezo parammezo = (Mezo) param;
            Int32 index = parammezo.Sor*_modell.Meret+parammezo.Oszlop;
           
            if (Lepes != null)
                Lepes(this, new MezoArgumentumok { Sor = Mezok[index].Sor, Oszlop = Mezok[index].Oszlop });

            OnPropertyChanged("Jatekos");
        }

        public NezetModell(Modell modell)
        {
            _modell = modell;
            _modell.TablaValtozas += new EventHandler<EventArgs>(TablavaltozasNezetModell);
            _modell.JatekVege += new EventHandler<JatekvegeArgumentumok>(JatekvegeNezetModell);

            UjjatekParancs = new Parancs(param => Ujjatekkor());
            BetoltesParancs = new Parancs(param => Betolteskor());
            MentesParancs = new Parancs(param => Menteskor());

            Mezok = new ObservableCollection<Mezo>();
            TablaBeallitas();
        }

        public void TablavaltozasNezetModell(object sender, EventArgs e)
        {
            OnPropertyChanged("Jatekos");
            foreach (Mezo mezo in Mezok)
            {
                Int32 sor = mezo.Sor;
                Int32 oszlop = mezo.Oszlop;
                Int32 ertek = _modell.Tabla(sor,oszlop);
                if (_modell.Fedett(sor, oszlop) == 0)
                {
                    if (ertek == 0)
                    {
                        mezo.Szoveg = String.Empty;
                    }
                    else if(ertek == -1)
                    {
                        mezo.Szovegszin = "Black";
                        mezo.Szoveg = "X";
                    }
                    else if(ertek == 1)
                    {
                        mezo.Szovegszin = "Red";
                        mezo.Szoveg = ertek.ToString();
                    }
                    else if (ertek == 2)
                    {
                        mezo.Szovegszin = "Blue";
                        mezo.Szoveg = ertek.ToString();
                    }
                    else if (ertek == 3)
                    {
                        mezo.Szovegszin = "Green";
                        mezo.Szoveg = ertek.ToString();
                    }
                    else if (ertek == 4)
                    {
                        mezo.Szovegszin = "Orange";
                        mezo.Szoveg = ertek.ToString();
                    }
                    else if (ertek == 5)
                    {
                        mezo.Szovegszin = "Purple";
                        mezo.Szoveg = ertek.ToString();
                    }
                    else if (ertek == 6)
                    {
                        mezo.Szovegszin = "Brown";
                        mezo.Szoveg = ertek.ToString();
                    }
                    else if (ertek == 7)
                    {
                        mezo.Szovegszin = "Yellow";
                        mezo.Szoveg = ertek.ToString();
                    }
                    else if (ertek == 8)
                    {
                        mezo.Szovegszin = "Gray";
                        mezo.Szoveg = ertek.ToString();
                    }
                    mezo.Hatter = "White";
                }
                else
                {
                    mezo.Hatter = "Aqua";
                }
            }
        }

        private void JatekvegeNezetModell(object sender, JatekvegeArgumentumok e)
        {
            if (e.Gyozelem == 1)
            {
                MessageBox.Show("A játék véget ért!" + Environment.NewLine +
                    "A nyertes a(z) " + e.Nyertes.ToString() + ". játékos.",
                    "Játék vége!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("A játék véget ért!" + Environment.NewLine +
                    "Az eredmény döntetlen.",
                    "Játék vége!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            _modell.Ujjatek_Modell(_modell.Meret);
            TablaBeallitas();
        }

        public void TablaBeallitas()
        {
            Mezok.Clear();
            for (Int32 i = 0; i < _modell.Meret; i++)
            {
                for (Int32 j = 0; j < _modell.Meret; j++)
                {
                    Mezok.Add(new Mezo
                    {
                        Szoveg = String.Empty,
                        Hatter = "Aqua",
                        Sor = i,
                        Oszlop = j,
                        LepesParancs = new Parancs(param =>
                        {
                            Lepeskor(param);
                        })
                    });
                }
            }
        }
    }
}
