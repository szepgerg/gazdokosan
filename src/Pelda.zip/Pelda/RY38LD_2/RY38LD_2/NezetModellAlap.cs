﻿using System;
using System.ComponentModel;

namespace RY38LD_2
{
    public abstract class NezetModellAlap : INotifyPropertyChanged
    {
        protected NezetModellAlap() { }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(String tulajdonsagNev)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(tulajdonsagNev));
            }
        }
    }
}
