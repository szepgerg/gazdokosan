﻿using System;
using System.Windows.Media;

namespace RY38LD_2
{
    public class Mezo : NezetModellAlap
    {
        private String _szoveg;
        private String _hatter;
        private String _szovegszin;

        public String Szoveg
        {
            get { return _szoveg; }
            set { _szoveg = value; OnPropertyChanged("Szoveg"); }
        }

        public String Hatter
        {
            get { return _hatter; }
            set { _hatter = value; OnPropertyChanged("Hatter"); }
        }

        public String Szovegszin
        {
            get { return _szovegszin; }
            set { _szovegszin = value; OnPropertyChanged("Szovegszin"); }
        }


        public Int32 Sor { get; set; }
       
        public Int32 Oszlop { get; set; }
       
        public Parancs LepesParancs { get; set; }
    }
}
