﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace RY38LD_2
{
    public partial class App : Application
    {
        private Modell _modell;
        private NezetModell _nezetmodell;
        private MainWindow _nezet;

        public App() { }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            _modell = new Modell();

            _nezetmodell = new NezetModell(_modell);
            _nezetmodell.Ujjatek += new EventHandler(Ujjatek_NezetModell);
            _nezetmodell.Lepes += new EventHandler<MezoArgumentumok>(Lepes_NezetModell);
            _nezetmodell.Betoltes += new EventHandler(Betoltes_NezetModell);
            _nezetmodell.Mentes += new EventHandler(Mentes_NezetModell);

            _nezet = new MainWindow();
            _nezet.DataContext = _nezetmodell;
            _nezet.Show();

            _modell.Ujjatek_Modell(6);
            _nezetmodell.TablaBeallitas();
        }

        private void Ujjatek_NezetModell(object sender, EventArgs e)
        {
            _modell.Ujjatek_Modell(_modell.Meret);
            _nezetmodell.TablaBeallitas();
        }

        private void Lepes_NezetModell(object sender, MezoArgumentumok e)
        {
            _modell.Lepes_Modell(e.Sor, e.Oszlop);
        }

        private void Betoltes_NezetModell(object sender, System.EventArgs e)
        {
            Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
            openFileDialog.Title = "Játék Betöltése";
            openFileDialog.Filter = "Aknekereso|*.akn";
            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    _modell.Betoltes_Modell(openFileDialog.FileName);
                    _nezetmodell.TablaBeallitas();
                    EventArgs e1 = new EventArgs();
                    _nezetmodell.TablavaltozasNezetModell(this,e1);
                }
                catch (FileKivetel)
                {
                    MessageBox.Show("A játék betöltése sikertelen!" + Environment.NewLine +
                        "A file-formátum, vagy az elérési út hibás.",
                        "File Betöltés", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("A játék betöltése sikertelen!" + Environment.NewLine +
                    "Nem választott ki file-t.",
                    "File Betöltés", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Mentes_NezetModell(object sender, EventArgs e)
        {
            Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
            saveFileDialog.Title = "Játék mentése!";
            saveFileDialog.Filter = "Aknakereso|*.akn";
            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    _modell.Mentes_Modell(saveFileDialog.FileName);
                }
                catch (FileKivetel)
                {
                    MessageBox.Show("A játék mentése sikertelen!" + Environment.NewLine + 
                        "A könyvtár nem írható, vagy hibás az elérési út.", 
                        "File Mentés", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("A játék mentése sikertelen!" + Environment.NewLine +
                    "Nem választott ki file-t.",
                    "File Mentés", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
